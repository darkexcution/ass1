// -----------------------------------------------------
// Assignment 1
// Part: The classes
// Written by: (Sitherankan Sinnappu 40264048)&(Paul Hong Phuc Pham 40264687)
// -----------------------------------------------------
package secondPackage;

import thirdPackage.Metro;

public class Tram extends Metro {
	private int yearOfCreation;
	private static long tramSerialNumber=30000;
	/**
	 * it is a default constructor of Tram
	 */
	public Tram() {
		super();
		yearOfCreation=0;
		this.setSerialNumber(tramSerialNumber);
		tramSerialNumber++;
	}
	/**
	 * it is a  parameterized constructor of tram
	 * 
	 * @param numberOfWheels this is the number of wheels
	 * @param maxSpeed this is the number of speed
	 * @param maximumWeight this is the maximum weight 
	 */ 
	public Tram(int numberOfWheels, double maxSpeed,int numberOfVehicles, String startingStation, String destinationStation,int numberOfStops,int yearOfCreation) {
		super(numberOfWheels, maxSpeed,numberOfVehicles,startingStation, destinationStation, numberOfStops);
		this.yearOfCreation=yearOfCreation;
		this.setSerialNumber(tramSerialNumber);
		tramSerialNumber++;
		
	}
	public Tram (Tram tm) {
		super(tm);
		this.yearOfCreation=tm.yearOfCreation;
		this.setSerialNumber(tramSerialNumber);
		tramSerialNumber++;
	}
	
	public static long getNextSerialNumber() {
		return tramSerialNumber;
	}

	public int getYearOfCreation() {
		return yearOfCreation;
	}

	public void setYearOfCreation(int yearOfCreation) {
		this.yearOfCreation = yearOfCreation;
	}
	
	@Override
	public String toString() {
		return "This Tram - serial #" + this.getSerialNumber() + "- has " + this.getNumberOfWheels()+ "wheels, has a maximum speed of "+ this.getMaxSpeed()+ " km/hr. It has "+ this.getNumberOfVehicles()+ "vehicles, its starting and destination stations are "+ this.getStartingStation() +" and "+  this.getDestinationStation() + " and it has "+ this.getNumberOfStops()+" stops. It was created in "+yearOfCreation+". ";
	}
	
	public boolean equals(Object x) {
		if((x== null)||(this.getClass()!=x.getClass()) )
			return false;
		else {
			Tram y= (Tram) x;
			if(this.getMaxSpeed() == y.getMaxSpeed() && this.getNumberOfWheels() == y.getNumberOfWheels() && this.getNumberOfVehicles()==y.getNumberOfVehicles() && this.getStartingStation() == y.getStartingStation() && this.getDestinationStation() == y.getDestinationStation() && this.getNumberOfStops() == y.getNumberOfStops() && this.yearOfCreation == y.yearOfCreation) 
				return true;
			else 
				return false;
			
		}
	}
	
	
}
