package comp249_ass2;

public class Vehicle {
private long serialNumber;


public Vehicle() {
	serialNumber=0;
}

public Vehicle (long serialNumber) {
	this.serialNumber=serialNumber;
}
public Vehicle (Vehicle vt) {
	this.serialNumber= vt.serialNumber;
}

public long getSerialNumber() {
	return serialNumber;
}

public void setSerialNumber(long serialNumber) {
	this.serialNumber = serialNumber;
}

@Override
public String toString() {
	return "This Vehicle - serial#" + serialNumber ;
}



}


