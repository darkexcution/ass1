// -----------------------------------------------------
// Assignment 1
// Part: The classes
// Written by: (Sitherankan Sinnappu 40264048)&(Paul Hong Phuc Pham 40264687)
// -----------------------------------------------------
package sixthPackage;

import firstPackage.WheeledTransportation;
import comp249_ass2.Vehicle;

public class Ferry extends Vehicle {
	
	private double maxSpeed;
	private double maxLoad;
	private static long ferrySerialNumber=70000;
	
	
	public Ferry() {
		super(ferrySerialNumber);
		maxSpeed=0;
		maxLoad=0;
		ferrySerialNumber++;
	}
	
	public Ferry(double maxSpeed, double maxLoad) {
		super(ferrySerialNumber);
		this.maxLoad=maxLoad;
		this.maxSpeed=maxSpeed;
		ferrySerialNumber++;
	}
	
	public Ferry (Ferry fy) {
		super(ferrySerialNumber);
		this.maxLoad=fy.maxLoad;
		this.maxSpeed=fy.maxSpeed;
		ferrySerialNumber++;
	}
	
	public static long getNextSerialNumber() {
		return ferrySerialNumber;
	}

	public double getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(double maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public double getMaxLoad() {
		return maxLoad;
	}

	public void setMaxLoad(double maxLoad) {
		this.maxLoad = maxLoad;
	}

	

	@Override
	public String toString() {
		return "This Ferry - serial#" + this.getSerialNumber() + "- has a maximum load of "+maxLoad+ " and a maximum speed of "+maxSpeed+".";
	}
	
	public boolean equals(Object x) {
		if((x== null)||(this.getClass()!=x.getClass()) )
			return false;
		else {
			Ferry y= (Ferry) x;
			if(this.maxSpeed==y.maxSpeed && this.maxLoad==y.maxLoad) 
				return true;
			else 
				return false;
			
		}
		
	}
	
	
	

}
