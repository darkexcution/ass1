// -----------------------------------------------------
// Assignment 1
// Part: The classes
// Written by: (Sitherankan Sinnappu 40264048)&(Paul Hong Phuc Pham 40264687)
// -----------------------------------------------------
package fifthPackage;

public class WorldWar2Airplane extends Aircraft {
	private boolean twinEngine;
	private static long WW2SN=80000;
	
	public WorldWar2Airplane() {
		super();
		twinEngine=false;
		this.setSerialNumber(WW2SN);
		WW2SN++;
	}
	
	public WorldWar2Airplane(double price,double maxElevation,boolean twinEngine) {
		super(price,maxElevation);
		this.twinEngine=twinEngine;
		this.setSerialNumber(WW2SN);
		WW2SN++;
	}
	
	public WorldWar2Airplane(WorldWar2Airplane WW2) {
		super(WW2);
		this.twinEngine=WW2.twinEngine;
		this.setSerialNumber(WW2SN);
		WW2SN++;
	}
	public static long getNextSerialNumber() {
		return WW2SN;
	}

	public boolean isTwinEngine() {
		return twinEngine;
	}

	public void setTwinEngine(boolean twinEngine) {
		this.twinEngine = twinEngine;
	}

	@Override
	public String toString() {
		return "This World War 2 Airplane - serial#" + this.getSerialNumber() + "- has a twin Engine: " +twinEngine+ ", has a price of "+ this.getPrice()+ "$ and a maximum elevation of "+ this.getMaxElevation()+".";
	}
	
	public boolean equals(Object x) {
		if((x== null)||(this.getClass()!=x.getClass()) )
			return false;
		else {
			WorldWar2Airplane y= (WorldWar2Airplane) x;
			if( this.getPrice()==y.getPrice() && this.getMaxElevation()==y.getMaxElevation() && this.twinEngine == y.twinEngine) 
				return true;
			else 
				return false;
			
		}
		
	}
	
}
