// -----------------------------------------------------
// Assignment 1
// Part: The classes
// Written by: (Sitherankan Sinnappu 40264048)&(Paul Hong Phuc Pham 40264687)
// -----------------------------------------------------
package fifthPackage;

import firstPackage.WheeledTransportation;
import comp249_ass2.Vehicle;

public class Aircraft extends Vehicle {
	private double price;
	private double maxElevation;
	
	
	public Aircraft() {
		super();
		price=0;
		maxElevation=0;
		
	}
	
	public Aircraft (double price,double maxElevation) {
		super();
		this.price=price;
		this.maxElevation=maxElevation;
		
		
	}
	
	public Aircraft(Aircraft ac) {
		super(ac.getSerialNumber()+1);
		this.maxElevation=ac.maxElevation;
		this.price=ac.price;
		
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getMaxElevation() {
		return maxElevation;
	}

	public void setMaxElevation(double maxElevation) {
		this.maxElevation = maxElevation;
	}

	
	@Override
	public String toString() {
		return "This Aircraft - serial#" + this.getSerialNumber() + "- has a price of "+ price+ "$ and a maximum elevation of "+ maxElevation+".";
	}
	
	public boolean equals(Object x) {
		if((x== null)||(this.getClass()!=x.getClass()) ) 
			return false;
		else {
			Aircraft y= (Aircraft) x;
			if(this.price==y.price && this.maxElevation==y.maxElevation) 
				return true;
			else 
				return false;
			
		}
		
	}
	
	

}
